# Геолокация SportRoom

## Android
После `flutter create .` добавьте в `android/app/src/main/AndroidManifest.xml` перед `<application>`:

```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
```

## iOS
В `ios/Runner/Info.plist` добавьте:

```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>SportRoom использует местоположение, чтобы показывать ближайшие спортивные игры.</string>
```

## Supabase
Перед запуском выполните обновлённый `supabase_schema.sql`. У площадок появились `latitude` и `longitude`.

Организация при создании площадки может указать координаты вручную или нажать «Взять моё местоположение». Пользователь нажимает «Моё местоположение», после чего список фильтруется по радиусу, а карта показывает площадки.

Карта использует OpenStreetMap tiles через `flutter_map`. Для коммерческого production-трафика нужно соблюдать политику использования тайлов OSM или подключить подходящий tile provider.
