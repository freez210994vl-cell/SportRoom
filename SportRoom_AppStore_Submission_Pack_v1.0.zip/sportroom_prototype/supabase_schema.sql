-- SportRoom v0.3: run this entire file in Supabase SQL Editor.
create extension if not exists "pgcrypto";
create table if not exists public.profiles (id uuid primary key references auth.users(id) on delete cascade, account_type text not null check (account_type in ('user','organization')), full_name text not null, phone text not null, city text not null, avatar_url text, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.organizations (id uuid primary key default gen_random_uuid(), owner_id uuid not null unique references public.profiles(id) on delete cascade, name text not null, phone text not null, city text not null, address text not null, logo_url text, created_at timestamptz not null default now());
create table if not exists public.venues (id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade, name text not null, address text not null, city text not null, sport_types text[] not null default '{}', latitude double precision, longitude double precision, created_at timestamptz not null default now());
alter table public.venues add column if not exists latitude double precision;
alter table public.venues add column if not exists longitude double precision;
create index if not exists venues_coordinates_idx on public.venues(latitude, longitude);
create table if not exists public.games (id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade, venue_id uuid not null references public.venues(id) on delete restrict, title text not null, sport text not null check (sport in ('football','volleyball','basketball')), starts_at timestamptz not null, ends_at timestamptz, max_players integer not null check (max_players between 1 and 100), status text not null default 'published' check (status in ('draft','published','cancelled','completed')), created_at timestamptz not null default now());
create table if not exists public.game_participants (game_id uuid not null references public.games(id) on delete cascade, user_id uuid not null references public.profiles(id) on delete cascade, joined_at timestamptz not null default now(), primary key (game_id,user_id));
create index if not exists venues_org_idx on public.venues(organization_id); create index if not exists games_org_idx on public.games(organization_id); create index if not exists games_starts_idx on public.games(starts_at); create index if not exists participants_user_idx on public.game_participants(user_id);
alter table public.profiles enable row level security; alter table public.organizations enable row level security; alter table public.venues enable row level security; alter table public.games enable row level security; alter table public.game_participants enable row level security;
create policy "profiles_select_authenticated" on public.profiles for select to authenticated using (true); create policy "profiles_insert_self" on public.profiles for insert to authenticated with check ((select auth.uid())=id); create policy "profiles_update_self" on public.profiles for update to authenticated using ((select auth.uid())=id) with check ((select auth.uid())=id);
create policy "organizations_select_authenticated" on public.organizations for select to authenticated using (true); create policy "organizations_insert_owner" on public.organizations for insert to authenticated with check ((select auth.uid())=owner_id); create policy "organizations_update_owner" on public.organizations for update to authenticated using ((select auth.uid())=owner_id) with check ((select auth.uid())=owner_id); create policy "organizations_delete_owner" on public.organizations for delete to authenticated using ((select auth.uid())=owner_id);
create policy "venues_select_authenticated" on public.venues for select to authenticated using (true); create policy "venues_insert_org_owner" on public.venues for insert to authenticated with check (exists(select 1 from public.organizations o where o.id=organization_id and o.owner_id=(select auth.uid()))); create policy "venues_update_org_owner" on public.venues for update to authenticated using (exists(select 1 from public.organizations o where o.id=organization_id and o.owner_id=(select auth.uid()))) with check (exists(select 1 from public.organizations o where o.id=organization_id and o.owner_id=(select auth.uid()))); create policy "venues_delete_org_owner" on public.venues for delete to authenticated using (exists(select 1 from public.organizations o where o.id=organization_id and o.owner_id=(select auth.uid())));
create policy "games_select_authenticated" on public.games for select to authenticated using (true); create policy "games_insert_org_owner" on public.games for insert to authenticated with check (exists(select 1 from public.organizations o where o.id=organization_id and o.owner_id=(select auth.uid()))); create policy "games_update_org_owner" on public.games for update to authenticated using (exists(select 1 from public.organizations o where o.id=organization_id and o.owner_id=(select auth.uid()))) with check (exists(select 1 from public.organizations o where o.id=organization_id and o.owner_id=(select auth.uid()))); create policy "games_delete_org_owner" on public.games for delete to authenticated using (exists(select 1 from public.organizations o where o.id=organization_id and o.owner_id=(select auth.uid())));
create policy "participants_select_authenticated" on public.game_participants for select to authenticated using (true); create policy "participants_insert_self" on public.game_participants for insert to authenticated with check ((select auth.uid())=user_id); create policy "participants_delete_self" on public.game_participants for delete to authenticated using ((select auth.uid())=user_id);
grant select,insert,update on public.profiles to authenticated; grant select,insert,update,delete on public.organizations to authenticated; grant select,insert,update,delete on public.venues to authenticated; grant select,insert,update,delete on public.games to authenticated; grant select,insert,delete on public.game_participants to authenticated;

-- SportRoom v0.4: atomic join operation.
-- This prevents two users from taking the last available spot at the same time.
drop function if exists public.join_game(uuid);
create or replace function public.join_game(p_game_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_max integer;
  v_count integer;
  v_status text;
  v_account_type text;
begin
  if v_uid is null then
    raise exception 'not_authenticated';
  end if;

  select account_type into v_account_type
  from public.profiles
  where id = v_uid;

  if v_account_type is distinct from 'user' then
    raise exception 'only_users_can_join';
  end if;

  select status, max_players into v_status, v_max
  from public.games
  where id = p_game_id
  for update;

  if not found then
    raise exception 'game_not_found';
  end if;

  if v_status <> 'published' then
    raise exception 'game_not_available';
  end if;

  if exists(select 1 from public.game_participants where game_id = p_game_id and user_id = v_uid) then
    return;
  end if;

  select count(*) into v_count
  from public.game_participants
  where game_id = p_game_id;

  if v_count >= v_max then
    raise exception 'game_is_full';
  end if;

  insert into public.game_participants(game_id, user_id)
  values (p_game_id, v_uid);
end;
$$;

revoke all on function public.join_game(uuid) from public;
grant execute on function public.join_game(uuid) to authenticated;

drop policy if exists "participants_insert_self" on public.game_participants;


-- SportRoom v0.7 migration
-- Creates profile rows after Supabase Auth signup without requiring a client session.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, account_type, phone, city)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'account_type', 'user'),
    new.raw_user_meta_data->>'phone',
    new.raw_user_meta_data->>'city'
  )
  on conflict (id) do update set
    full_name = excluded.full_name,
    account_type = excluded.account_type,
    phone = excluded.phone,
    city = excluded.city;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Organization records are created by the app after login, when a session exists.
create unique index if not exists organizations_owner_id_unique
on public.organizations(owner_id);

-- Prevent duplicate memberships.
create unique index if not exists game_participants_game_user_unique
on public.game_participants(game_id, user_id);
