
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://mfvtwrdaylgpfqrldesf.supabase.co',
    publishableKey: 'sb_publishable_raYMEqoP1LLr5J12IAH2qQ_YjL0tWDE',
  );
  runApp(const SportRoomApp());
}
final supabase = Supabase.instance.client;

class SportRoomApp extends StatelessWidget {
  const SportRoomApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SportRoom',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        scaffoldBackgroundColor: const Color(0xFFF6F7F9),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1769FF)),
      ),
      home: const AuthGate(),
    );
  }
}



class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<AuthState>(
    stream: supabase.auth.onAuthStateChange,
    builder: (context, snapshot) => supabase.auth.currentSession == null ? const AuthPage() : const LoadingProfilePage(),
  );
}

class LoadingProfilePage extends StatefulWidget {
  const LoadingProfilePage({super.key});
  @override State<LoadingProfilePage> createState() => _LoadingProfilePageState();
}
class _LoadingProfilePageState extends State<LoadingProfilePage> {
  Account? account; String? error;
  @override void initState(){super.initState(); load();}
  Future<void> load() async {
    try {
      final user=supabase.auth.currentUser!;
      final row=await supabase.from('profiles').select().eq('id', user.id).maybeSingle();
      if(row==null){setState(()=>error='Профиль ещё не создан. Подтвердите email и войдите снова.');return;}
      final type=row['account_type']=='organization'?AccountType.organization:AccountType.user;
      String? address;
      if(type==AccountType.organization){
        final org=await supabase.from('organizations').select('address').eq('owner_id', user.id).maybeSingle();
        address=org?['address'] as String?;
      }
      setState(()=>account=Account(type:type,name:(row['full_name']??'') as String,email:user.email??'',phone:(row['phone']??'') as String,city:(row['city']??'') as String,organizationAddress:address));
    } catch(e){setState(()=>error='Не удалось загрузить профиль: $e');}
  }
  @override Widget build(BuildContext context){
    if(account!=null)return AuthenticatedShell(account:account!);
    return Scaffold(body:Center(child:error==null?const CircularProgressIndicator():Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[Text(error!,textAlign:TextAlign.center),const SizedBox(height:16),FilledButton(onPressed:()=>supabase.auth.signOut(),child:const Text('Вернуться ко входу'))]))));
  }
}

enum AccountType { user, organization }

class Account {
  final AccountType type;
  final String name;
  final String email;
  final String phone;
  final String city;
  final String? organizationAddress;
  Account({
    required this.type,
    required this.name,
    required this.email,
    required this.phone,
    required this.city,
    this.organizationAddress,
  });
}


Future<void> ensureProfileAndOrganization({
  required String userId,
  required AccountType type,
  required String name,
  required String phone,
  required String city,
  String? address,
}) async {
  final client = Supabase.instance.client;
  await client.from('profiles').upsert({
    'id': userId,
    'full_name': name,
    'phone': phone,
    'city': city,
    'account_type': type == AccountType.organization ? 'organization' : 'user',
  });

  if (type == AccountType.organization) {
    await client.from('organizations').upsert({
      'owner_id': userId,
      'name': name,
      'phone': phone,
      'city': city,
      'address': address,
    }, onConflict: 'owner_id');
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool login = true;
  AccountType type = AccountType.user;
  final name = TextEditingController();
  final email = TextEditingController();
  final phone = TextEditingController();
  final password = TextEditingController();
  final city = TextEditingController();
  final address = TextEditingController();

  Future<void> submit() async {
    if (email.text.trim().isEmpty || password.text.length < 6 ||
        (!login && (name.text.trim().isEmpty || phone.text.trim().isEmpty || city.text.trim().isEmpty))) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Заполните поля. Пароль — минимум 6 символов.')));
      return;
    }
    try {
      if (login) {
        await supabase.auth.signInWithPassword(email: email.text.trim(), password: password.text);
      } else {
        final response=await supabase.auth.signUp(email: email.text.trim(), password: password.text);
        final user=response.user;
        if(user==null) throw const AuthException('Не удалось создать аккаунт');
        await supabase.from('profiles').insert({'id':user.id,'account_type':type==AccountType.organization?'organization':'user','full_name':name.text.trim(),'phone':phone.text.trim(),'city':city.text.trim()});
        if(type==AccountType.organization){
          await supabase.from('organizations').insert({'owner_id':user.id,'name':name.text.trim(),'phone':phone.text.trim(),'city':city.text.trim(),'address':address.text.trim()});
        }
        if(response.session==null && mounted){
          showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Почти готово'),content:const Text('Проверьте email и подтвердите регистрацию. После подтверждения войдите в приложение.'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Понятно'))]));
        }
      }
    } on AuthException catch(e){if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message)));}
      catch(e){if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Ошибка: $e')));}
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(24, 38, 24, 30),
        children: [
          const Icon(Icons.sports_soccer, size: 52, color: Color(0xFF1769FF)),
          const SizedBox(height: 14),
          const Text('SportRoom', textAlign: TextAlign.center, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text(login ? 'Войдите, чтобы найти свою игру' : 'Создайте аккаунт за минуту',
              textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 28),
          if (!login) ...[
            const Text('Тип аккаунта', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            SegmentedButton<AccountType>(
              segments: const [
                ButtonSegment(value: AccountType.user, icon: Icon(Icons.person_outline), label: Text('Пользователь')),
                ButtonSegment(value: AccountType.organization, icon: Icon(Icons.business_outlined), label: Text('Организация')),
              ],
              selected: {type},
              onSelectionChanged: (v) => setState(() => type = v.first),
            ),
            const SizedBox(height: 18),
            AuthField(controller: name, label: type == AccountType.user ? 'Имя и фамилия' : 'Название организации', icon: type == AccountType.user ? Icons.person_outline : Icons.business_outlined),
            if (type == AccountType.organization)
              AuthField(controller: address, label: 'Адрес организации', icon: Icons.location_on_outlined),
            AuthField(controller: phone, label: 'Телефон', icon: Icons.phone_outlined, keyboard: TextInputType.phone),
            AuthField(controller: city, label: 'Город', icon: Icons.location_city_outlined),
          ],
          AuthField(controller: email, label: 'Email', icon: Icons.email_outlined, keyboard: TextInputType.emailAddress),
          AuthField(controller: password, label: 'Пароль', icon: Icons.lock_outline, obscure: true),
          if (login)
            Align(alignment: Alignment.centerRight, child: TextButton(onPressed: () {
              showDialog(context: context, builder: (_) => const AlertDialog(
                title: Text('Восстановление пароля'),
                content: Text('В реальной версии здесь будет отправка ссылки на email.'),
              ));
            }, child: const Text('Забыли пароль?'))),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: submit,
            child: Padding(padding: const EdgeInsets.all(13), child: Text(login ? 'Войти' : 'Создать аккаунт')),
          ),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: () => setState(() => login = !login),
            child: Text(login ? 'Создать новый аккаунт' : 'У меня уже есть аккаунт'),
          ),
          if (!login) ...[
            const SizedBox(height: 16),
            const Text('Продолжая, вы соглашаетесь с правилами SportRoom и политикой конфиденциальности.',
              textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ],
      ),
    ),
  );
}

class AuthField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final bool obscure;
  final TextInputType? keyboard;
  const AuthField({super.key, required this.controller, required this.label, required this.icon, this.obscure=false, this.keyboard});
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 13),
    child: TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboard,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
      ),
    ),
  );
}

class AuthenticatedShell extends StatefulWidget {
  final Account account;
  const AuthenticatedShell({super.key, required this.account});
  @override State<AuthenticatedShell> createState() => _AuthenticatedShellState();
}

class _AuthenticatedShellState extends State<AuthenticatedShell> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final isOrg = widget.account.type == AccountType.organization;
    final pages = isOrg
        ? [const OrgHome(), const OrgGames(), const CreateGame(), OrgAccountProfile(account: widget.account)]
        : [const Home(), const Games(), const MyGames(), UserAccountProfile(account: widget.account)];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: isOrg ? const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Главная'),
          NavigationDestination(icon: Icon(Icons.sports_soccer_outlined), selectedIcon: Icon(Icons.sports_soccer), label: 'Игры'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Создать'),
          NavigationDestination(icon: Icon(Icons.business_outlined), selectedIcon: Icon(Icons.business), label: 'Профиль'),
        ] : const [
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Главная'),
          NavigationDestination(icon: Icon(Icons.search_outlined), selectedIcon: Icon(Icons.search), label: 'Игры'),
          NavigationDestination(icon: Icon(Icons.event_outlined), selectedIcon: Icon(Icons.event), label: 'Мои игры'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
        ],
      ),
    );
  }
}

class UserAccountProfile extends StatelessWidget {
  final Account account;
  const UserAccountProfile({super.key, required this.account});
  @override Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 24, 20, 90),
    children: [
      const Center(child: CircleAvatar(radius: 48, child: Icon(Icons.person, size: 44))),
      const SizedBox(height: 12),
      Center(child: Text(account.name, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
      Center(child: Text('${account.city} · ${account.email}', style: const TextStyle(color: Colors.black54))),
      const SizedBox(height: 28),
      const SettingsTile(icon: Icons.sports_soccer, title: 'Мои виды спорта', subtitle: 'Футбол · Баскетбол'),
      const SettingsTile(icon: Icons.notifications_outlined, title: 'Уведомления', subtitle: 'Включены'),
      const SettingsTile(icon: Icons.location_on_outlined, title: 'Местоположение', subtitle: 'Разрешено'),
      const SettingsTile(icon: Icons.shield_outlined, title: 'Безопасность', subtitle: 'Аккаунт защищён'),
      const SizedBox(height: 20),
      OutlinedButton.icon(onPressed: () => supabase.auth.signOut(),
        icon: const Icon(Icons.logout), label: const Text('Выйти')),
    ],
  );
}

class OrgAccountProfile extends StatelessWidget {
  final Account account;
  const OrgAccountProfile({super.key, required this.account});
  @override Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 24, 20, 90),
    children: [
      const Center(child: CircleAvatar(radius: 48, child: Icon(Icons.business, size: 44))),
      const SizedBox(height: 12),
      Center(child: Text(account.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold))),
      Center(child: Text('${account.city} · ${account.email}', style: const TextStyle(color: Colors.black54))),
      if (account.organizationAddress != null)
        Center(child: Text(account.organizationAddress!, style: const TextStyle(color: Colors.black54))),
      const SizedBox(height: 28),
      const SettingsTile(icon: Icons.location_on_outlined, title: 'Мои площадки', subtitle: '3 площадки'),
      const SettingsTile(icon: Icons.people_outline, title: 'Команда организации', subtitle: '4 администратора'),
      const SettingsTile(icon: Icons.notifications_outlined, title: 'Уведомления', subtitle: 'Включены'),
      const SettingsTile(icon: Icons.settings_outlined, title: 'Настройки клуба', subtitle: 'Изменить профиль'),
      const SizedBox(height: 20),
      OutlinedButton.icon(onPressed: () => supabase.auth.signOut(),
        icon: const Icon(Icons.logout), label: const Text('Выйти')),
    ],
  );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;
  bool orgMode = false;

  @override
  Widget build(BuildContext context) {
    final pages = orgMode
        ? const [OrgHome(), OrgGames(), CreateGame(), OrgProfile()]
        : const [Home(), Games(), MyGames(), Profile()];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: orgMode
            ? const [
                NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Главная'),
                NavigationDestination(icon: Icon(Icons.sports_soccer_outlined), selectedIcon: Icon(Icons.sports_soccer), label: 'Игры'),
                NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Создать'),
                NavigationDestination(icon: Icon(Icons.business_outlined), selectedIcon: Icon(Icons.business), label: 'Профиль'),
              ]
            : const [
                NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Главная'),
                NavigationDestination(icon: Icon(Icons.search_outlined), selectedIcon: Icon(Icons.search), label: 'Игры'),
                NavigationDestination(icon: Icon(Icons.event_outlined), selectedIcon: Icon(Icons.event), label: 'Мои игры'),
                NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
              ],
      ),
      floatingActionButton: !orgMode && tab == 0
          ? FloatingActionButton.extended(
              onPressed: () => showModalBottomSheet(
                context: context,
                showDragHandle: true,
                builder: (_) => const RoleSheet(),
              ),
              icon: const Icon(Icons.add),
              label: const Text('Создать игру'),
            )
          : null,
    );
  }
}

class RoleSheet extends StatelessWidget {
  const RoleSheet({super.key});
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Кто вы?', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Организации создают официальные комнаты и управляют площадками.'),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.person), label: const Text('Я пользователь')),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.business), label: const Text('Я организация')),
      const SizedBox(height: 12),
    ]),
  );
}


class SportRoomData {
  static String emoji(String sport) => switch (sport) {
    'football' => '⚽',
    'volleyball' => '🏐',
    'basketball' => '🏀',
    _ => '🏅',
  };

  static Future<String> organizationId() async {
    final uid = supabase.auth.currentUser!.id;
    final row = await supabase.from('organizations').select('id').eq('owner_id', uid).single();
    return row['id'] as String;
  }

  static Future<List<Map<String, dynamic>>> publicGames() async {
    final rows = await supabase
        .from('games')
        .select('id, organization_id, venue_id, title, sport, starts_at, ends_at, max_players, status, venues(name,address,city,latitude,longitude), organizations(name)')
        .eq('status', 'published')
        .gte('starts_at', DateTime.now().toUtc().toIso8601String())
        .order('starts_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  static Future<int> participantCount(String gameId) async {
    final rows = await supabase.from('game_participants').select('user_id').eq('game_id', gameId);
    return rows.length;
  }

  static Future<bool> isJoined(String gameId) async {
    final uid = supabase.auth.currentUser!.id;
    final row = await supabase.from('game_participants').select('game_id').eq('game_id', gameId).eq('user_id', uid).maybeSingle();
    return row != null;
  }

  static Future<void> joinGame(String gameId) async {
    await supabase.rpc('join_game', params: {'p_game_id': gameId});
  }

  static Future<void> leaveGame(String gameId) async {
    final uid = supabase.auth.currentUser!.id;
    await supabase.from('game_participants').delete().eq('game_id', gameId).eq('user_id', uid);
  }

  static String dateTime(String value) {
    final d = DateTime.parse(value).toLocal();
    final date = '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}';
    final time = '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    return '$date · $time';
  }
}

class Home extends StatelessWidget {
  const Home({super.key});
  @override Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
    future: SportRoomData.publicGames(),
    builder: (context, snapshot) => ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 100),
      children: [
        Row(children: [const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Привет! 👋', style: TextStyle(fontSize: 16, color: Colors.black54)), SizedBox(height: 3), Text('Найдём игру?', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800))])), const CircleAvatar(radius: 24, child: Icon(Icons.person))]),
        const SizedBox(height: 22),
        const TextField(decoration: InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Футбол, волейбол, баскетбол…', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(16)), borderSide: BorderSide.none))),
        const SizedBox(height: 20),
        const SectionTitle(title: 'Выберите спорт'), const SizedBox(height: 12),
        Row(children: const [SportChip('⚽', 'Футбол'), SizedBox(width: 10), SportChip('🏐', 'Волейбол'), SizedBox(width: 10), SportChip('🏀', 'Баскетбол')]),
        const SizedBox(height: 24), const SectionTitle(title: 'Игры рядом'), const SizedBox(height: 12),
        if (snapshot.connectionState == ConnectionState.waiting) const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()))
        else if (snapshot.hasError) Text('Не удалось загрузить игры: ${snapshot.error}')
        else if ((snapshot.data ?? []).isEmpty) const EmptyState(text: 'Пока нет опубликованных игр. Организации могут создать первую игру.' )
        else ...(snapshot.data!.take(10).map((g) => RealGameCard(game: g))),
      ],
    ),
  );
}

class Games extends StatefulWidget {
  const Games({super.key});
  @override State<Games> createState() => _GamesState();
}

class _GamesState extends State<Games> {
  late Future<List<Map<String,dynamic>>> future;
  bool mapMode = false;
  String sport = 'all';
  double radiusKm = 10;
  Position? position;
  String? locationMessage;

  @override void initState(){super.initState(); future=SportRoomData.publicGames();}

  Future<void> _locate() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        setState(()=>locationMessage='Включите геолокацию на телефоне.'); return;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        setState(()=>locationMessage='Разрешите SportRoom доступ к местоположению.'); return;
      }
      final pos = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.medium));
      if (mounted) setState(() { position=pos; locationMessage=null; });
    } catch (e) {
      if (mounted) setState(()=>locationMessage='Не удалось определить местоположение.');
    }
  }

  double? _distanceKm(Map<String,dynamic> g) {
    if (position == null) return null;
    final v=(g['venues'] as Map?) ?? {};
    final lat=(v['latitude'] as num?)?.toDouble();
    final lng=(v['longitude'] as num?)?.toDouble();
    if (lat == null || lng == null) return null;
    return Geolocator.distanceBetween(position!.latitude, position!.longitude, lat, lng)/1000;
  }

  List<Map<String,dynamic>> _filtered(List<Map<String,dynamic>> games) {
    final result = games.where((g) {
      if (sport != 'all' && g['sport'] != sport) return false;
      final d = _distanceKm(g);
      if (position != null && d != null && d > radiusKm) return false;
      return true;
    }).toList();
    if (position != null) {
      result.sort((a,b) => (_distanceKm(a) ?? 999999).compareTo(_distanceKm(b) ?? 999999));
    }
    return result;
  }

  @override Widget build(BuildContext context)=>FutureBuilder<List<Map<String,dynamic>>>(
    future:future,
    builder:(context,snapshot){
      if(snapshot.connectionState==ConnectionState.waiting) return const Center(child:CircularProgressIndicator());
      if(snapshot.hasError) return Center(child:Padding(padding:const EdgeInsets.all(20),child:Text('Ошибка: ${snapshot.error}')));
      final games=_filtered(snapshot.data ?? []);
      final center=position!=null ? LatLng(position!.latitude,position!.longitude) : const LatLng(-36.8485,174.7633);
      return Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(20,18,20,10),child:Row(children:[
          const Expanded(child:Text('Игры рядом',style:TextStyle(fontSize:30,fontWeight:FontWeight.w800))),
          IconButton(onPressed:_locate,tooltip:'Моё местоположение',icon:const Icon(Icons.my_location)),
          SegmentedButton<bool>(segments:const [ButtonSegment(value:false,icon:Icon(Icons.list),label:Text('Список')),ButtonSegment(value:true,icon:Icon(Icons.map_outlined),label:Text('Карта'))],selected:{mapMode},onSelectionChanged:(v)=>setState(()=>mapMode=v.first)),
        ])),
        SizedBox(height:52,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:20),children:[
          ChoiceChip(label:const Text('Все'),selected:sport=='all',onSelected:(_)=>setState(()=>sport='all')),
          const SizedBox(width:8),ChoiceChip(label:const Text('⚽ Футбол'),selected:sport=='football',onSelected:(_)=>setState(()=>sport='football')),
          const SizedBox(width:8),ChoiceChip(label:const Text('🏐 Волейбол'),selected:sport=='volleyball',onSelected:(_)=>setState(()=>sport='volleyball')),
          const SizedBox(width:8),ChoiceChip(label:const Text('🏀 Баскетбол'),selected:sport=='basketball',onSelected:(_)=>setState(()=>sport='basketball')),
          const SizedBox(width:8),ChoiceChip(label:Text('До ${radiusKm.toInt()} км'),selected:position!=null,onSelected:(_)=>_locate()),
          const SizedBox(width:8),PopupMenuButton<double>(initialValue:radiusKm,onSelected:(v)=>setState(()=>radiusKm=v),itemBuilder:(_)=>const [PopupMenuItem(value:5,child:Text('Радиус 5 км')),PopupMenuItem(value:10,child:Text('Радиус 10 км')),PopupMenuItem(value:25,child:Text('Радиус 25 км')),PopupMenuItem(value:50,child:Text('Радиус 50 км'))],child:const Chip(avatar:Icon(Icons.tune,size:18),label:Text('Радиус'))),
        ])),
        if(locationMessage!=null) Padding(padding:const EdgeInsets.fromLTRB(20,4,20,8),child:Text(locationMessage!,style:const TextStyle(color:Colors.black54))),
        Expanded(child:mapMode ? NearbyMap(games:games,center:center,position:position) : RefreshIndicator(onRefresh:() async{setState(()=>future=SportRoomData.publicGames());await future;},child:games.isEmpty?const ListView(children:[EmptyState(text:'Нет игр в выбранном радиусе или виде спорта.')]):ListView.builder(padding:const EdgeInsets.fromLTRB(20,12,20,90),itemCount:games.length,itemBuilder:(c,i)=>RealGameCard(game:games[i])))),
      ]);
    });
}

class NearbyMap extends StatelessWidget {
  final List<Map<String,dynamic>> games; final LatLng center; final Position? position;
  const NearbyMap({super.key,required this.games,required this.center,this.position});
  @override Widget build(BuildContext context){
    final markers=<Marker>[];
    if(position!=null) markers.add(Marker(point:center,width:48,height:48,child:const Icon(Icons.my_location,size:34,color:Colors.blue)));
    for(final g in games){
      final v=(g['venues'] as Map?) ?? {};
      final lat=(v['latitude'] as num?)?.toDouble(), lng=(v['longitude'] as num?)?.toDouble();
      if(lat==null||lng==null) continue;
      markers.add(Marker(point:LatLng(lat,lng),width:52,height:52,child:GestureDetector(onTap:()=>showModalBottomSheet(context:context,showDragHandle:true,builder:(_)=>Padding(padding:const EdgeInsets.all(20),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(SportRoomData.emoji(g['sport'] as String)+' '+g['title'],style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text('${v['name']??''} · ${v['address']??''}'),Text(SportRoomData.dateTime(g['starts_at'] as String)),const SizedBox(height:14),FilledButton(onPressed:()=>Navigator.pop(context),child:const Text('Открыть игру'))]))),child:const Icon(Icons.location_on,size:42,color:Color(0xFF1769FF)))));
    }
    return Stack(children:[FlutterMap(options:MapOptions(initialCenter:center,initialZoom:12),children:[TileLayer(urlTemplate:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',userAgentPackageName:'com.sportroom.app'),MarkerLayer(markers:markers)]),Positioned(top:12,right:12,child:Card(child:Padding(padding:const EdgeInsets.symmetric(horizontal:12,vertical:8),child:Text('${games.length} игр'))))]);
  }
}

class MyGames extends StatefulWidget {
  const MyGames({super.key});
  @override State<MyGames> createState()=>_MyGamesState();
}
class _MyGamesState extends State<MyGames>{
  late Future<List<Map<String,dynamic>>> future;
  @override void initState(){super.initState();future=_load();}
  Future<List<Map<String,dynamic>>> _load() async {
    final uid=supabase.auth.currentUser!.id;
    final rows=await supabase.from('game_participants').select('game_id, games(id,organization_id,venue_id,title,sport,starts_at,ends_at,max_players,status,venues(name,address,city),organizations(name))').eq('user_id',uid);
    return rows.map<Map<String,dynamic>>((r)=>Map<String,dynamic>.from(r['games'] as Map)).where((g)=>g['status']=='published').toList();
  }
  @override Widget build(BuildContext context)=>FutureBuilder<List<Map<String,dynamic>>>(future:future,builder:(context,snapshot)=>ListView(padding:const EdgeInsets.fromLTRB(20,18,20,90),children:[const Text('Мои игры',style:TextStyle(fontSize:30,fontWeight:FontWeight.w800)),const SizedBox(height:18),if(snapshot.connectionState==ConnectionState.waiting)const Center(child:CircularProgressIndicator())else if(snapshot.hasError)Text('Ошибка: ${snapshot.error}')else if((snapshot.data??[]).isEmpty)const EmptyState(text:'Вы ещё не присоединились ни к одной игре')else ...snapshot.data!.map((g)=>RealGameCard(game:g,joinedBadge:true))]));
}

class RealGameCard extends StatefulWidget {
  final Map<String,dynamic> game; final bool joinedBadge;
  const RealGameCard({super.key,required this.game,this.joinedBadge=false});
  @override State<RealGameCard> createState()=>_RealGameCardState();
}
class _RealGameCardState extends State<RealGameCard>{
  int? count; bool? joined;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async {final id=widget.game['id'] as String; try{final values=await Future.wait([SportRoomData.participantCount(id),SportRoomData.isJoined(id)]);if(mounted)setState(() { count = values[0] as int; joined = values[1] as bool; });}catch(_){}}
  @override Widget build(BuildContext context){
    final g=widget.game; final venue=(g['venues'] as Map?) ?? {}; final org=(g['organizations'] as Map?) ?? {};
    return Card(margin:const EdgeInsets.only(bottom:12),elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)),child:InkWell(borderRadius:BorderRadius.circular(18),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>GameDetail(game:g))).then((_)=>_load()),child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[Container(width:52,height:52,decoration:BoxDecoration(color:const Color(0xFFEAF1FF),borderRadius:BorderRadius.circular(15)),alignment:Alignment.center,child:Text(SportRoomData.emoji(g['sport'] as String),style:const TextStyle(fontSize:27))),const SizedBox(width:13),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(g['title'] as String,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)),const SizedBox(height:5),Text((org['name']??venue['name']??'Площадка').toString(),style:const TextStyle(color:Colors.black54)),const SizedBox(height:7),Text(SportRoomData.dateTime(g['starts_at'] as String),style:const TextStyle(fontWeight:FontWeight.w600))])),Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text('${count??'…'} / ${g['max_players']}',style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:7),if((g['venues'] as Map?)?['latitude'] != null)Text('📍 ${((g['venues'] as Map?)?['city']??'').toString()}',style:const TextStyle(fontSize:11,color:Colors.black54)),if(joined==true||widget.joinedBadge)const Icon(Icons.check_circle,color:Color(0xFF1769FF),size:18)])]))));
  }
}

class GameDetail extends StatefulWidget {
  final Map<String,dynamic> game;
  const GameDetail({super.key,required this.game});
  @override State<GameDetail> createState()=>_GameDetailState();
}
class _GameDetailState extends State<GameDetail>{
  bool loading=true, joined=false; int count=0; List<Map<String,dynamic>> participants=[];
  Map<String,dynamic> get g=>widget.game;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async {try{final id=g['id'] as String; final results=await Future.wait([SportRoomData.participantCount(id),SportRoomData.isJoined(id),supabase.from('game_participants').select('user_id, joined_at, profiles(full_name)').eq('game_id',id).order('joined_at')]); if(mounted)setState(() { count=results[0] as int; joined=results[1] as bool; participants=List<Map<String,dynamic>>.from(results[2] as List); loading=false; });}catch(e){if(mounted){setState(()=>loading=false);ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Ошибка: $e')));}}}
  Future<void> _toggleJoin() async {setState(()=>loading=true);try{if(joined){await SportRoomData.leaveGame(g['id'] as String);}else{await SportRoomData.joinGame(g['id'] as String);}await _load();}catch(e){setState(()=>loading=false);if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('PostgrestException(message: ','').replaceFirst(RegExp(r',.*'),''))));}}
  @override Widget build(BuildContext context){final venue=(g['venues'] as Map?)??{}; final org=(g['organizations'] as Map?)??{};return Scaffold(appBar:AppBar(title:const Text('Комната')),body:ListView(padding:const EdgeInsets.all(20),children:[Container(height:170,decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),color:const Color(0xFFDCE8FF)),child:const Center(child:Icon(Icons.location_on,size:60))),const SizedBox(height:20),Text('${SportRoomData.emoji(g['sport'] as String)}  ${g['title']}',style:const TextStyle(fontSize:25,fontWeight:FontWeight.w800)),const SizedBox(height:12),InfoLine(Icons.calendar_today,SportRoomData.dateTime(g['starts_at'] as String)),InfoLine(Icons.location_on_outlined,'${venue['name']??'Площадка'} · ${venue['address']??''}'),InfoLine(Icons.business_outlined,(org['name']??'Организация').toString()),InfoLine(Icons.people_outline,'$count / ${g['max_players']} участников'),const SizedBox(height:18),const Text('Участники',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:10),if(loading&&participants.isEmpty)const Center(child:CircularProgressIndicator())else if(participants.isEmpty)const Text('Пока никто не присоединился.')else ...participants.map((p){final profile=(p['profiles'] as Map?)??{};final n=(profile['full_name']??'Игрок').toString();return ListTile(leading:CircleAvatar(child:Text(n.isNotEmpty?n.substring(0,1).toUpperCase():'?')),title:Text(n));}),const SizedBox(height:18),if(supabase.auth.currentUser!=null)FilledButton.icon(onPressed:loading?null:_toggleJoin,icon:Icon(joined?Icons.exit_to_app:Icons.check),label:Padding(padding:const EdgeInsets.all(13),child:Text(joined?'Выйти из игры':'Присоединиться к игре')))]));}
}

class OrgHome extends StatefulWidget { const OrgHome({super.key}); @override State<OrgHome> createState()=>_OrgHomeState(); }
class _OrgHomeState extends State<OrgHome>{
  late Future<List<Map<String,dynamic>>> future;
  @override void initState(){super.initState();future=_load();}
  Future<List<Map<String,dynamic>>> _load() async {final id=await SportRoomData.organizationId();final rows=await supabase.from('games').select('id,title,sport,starts_at,max_players,status,venues(name,address,city)').eq('organization_id',id).order('starts_at');return List<Map<String,dynamic>>.from(rows);}
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.fromLTRB(20,18,20,90),children:[Row(children:[const Expanded(child:Text('Панель клуба',style:TextStyle(fontSize:29,fontWeight:FontWeight.w800))),const CircleAvatar(child:Icon(Icons.business))]),const SizedBox(height:20),const Row(children:[StatBox('Активные игры','—'),SizedBox(width:10),StatBox('Участники','—'),SizedBox(width:10),StatBox('Площадки','—')]),const SizedBox(height:26),const SectionTitle(title:'Мои игры'),const SizedBox(height:10),FutureBuilder<List<Map<String,dynamic>>>(future:future,builder:(context,snapshot)=>snapshot.connectionState==ConnectionState.waiting?const Center(child:CircularProgressIndicator()):snapshot.hasError?Text('Ошибка: ${snapshot.error}'):snapshot.data!.isEmpty?const EmptyState(text:'Создайте первую площадку и игру.'):Column(children:snapshot.data!.map((g)=>RealGameCard(game:g)).toList()))]);
}

class OrgGames extends StatefulWidget { const OrgGames({super.key}); @override State<OrgGames> createState()=>_OrgGamesState(); }
class _OrgGamesState extends State<OrgGames>{
  late Future<List<Map<String,dynamic>>> future; @override void initState(){super.initState();future=_load();}
  Future<List<Map<String,dynamic>>> _load() async {final id=await SportRoomData.organizationId();final rows=await supabase.from('games').select('id,title,sport,starts_at,max_players,status,venues(name,address,city),organizations(name)').eq('organization_id',id).order('starts_at');return List<Map<String,dynamic>>.from(rows);}
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.fromLTRB(20,18,20,90),children:[const Text('Мои мероприятия',style:TextStyle(fontSize:29,fontWeight:FontWeight.w800)),const SizedBox(height:18),FutureBuilder<List<Map<String,dynamic>>>(future:future,builder:(context,snapshot)=>snapshot.connectionState==ConnectionState.waiting?const Center(child:CircularProgressIndicator()):snapshot.hasError?Text('Ошибка: ${snapshot.error}'):snapshot.data!.isEmpty?const EmptyState(text:'У вас пока нет игр.'):Column(children:snapshot.data!.map((g)=>RealGameCard(game:g)).toList()))]);
}

class CreateGame extends StatefulWidget { const CreateGame({super.key}); @override State<CreateGame> createState()=>_CreateGameState(); }
class _CreateGameState extends State<CreateGame>{
  String sport='football'; final title=TextEditingController(); final max=TextEditingController(text:'10'); DateTime? starts; DateTime? ends; String? venueId; bool busy=false; List<Map<String,dynamic>> venues=[];
  @override void initState(){super.initState();_loadVenues();}
  Future<void> _loadVenues() async {try{final id=await SportRoomData.organizationId();final rows=await supabase.from('venues').select().eq('organization_id',id).order('name');if(mounted)setState(()=>venues=List<Map<String,dynamic>>.from(rows));}catch(e){}}
  Future<void> _addVenue() async {final name=TextEditingController(),address=TextEditingController(),city=TextEditingController(),lat=TextEditingController(),lng=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Новая площадка'),content:SingleChildScrollView(child:Column(children:[AuthField(controller:name,label:'Название',icon:Icons.sports_soccer),AuthField(controller:address,label:'Адрес',icon:Icons.location_on_outlined),AuthField(controller:city,label:'Город',icon:Icons.location_city_outlined),Row(children:[Expanded(child:AuthField(controller:lat,label:'Широта',icon:Icons.north)),const SizedBox(width:8),Expanded(child:AuthField(controller:lng,label:'Долгота',icon:Icons.east))]),TextButton.icon(onPressed:()async{try{final p=await Geolocator.getCurrentPosition(locationSettings:const LocationSettings(accuracy:LocationAccuracy.medium));lat.text=p.latitude.toStringAsFixed(6);lng.text=p.longitude.toStringAsFixed(6);}catch(_){}} ,icon:const Icon(Icons.my_location),label:const Text('Взять моё местоположение'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Создать'))]));if(ok==true){final latitude=double.tryParse(lat.text.replaceAll(',','.')),longitude=double.tryParse(lng.text.replaceAll(',','.'));if(name.text.trim().isEmpty||address.text.trim().isEmpty||city.text.trim().isEmpty||latitude==null||longitude==null){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Укажите адрес и координаты площадки.')));return;}try{final org=await SportRoomData.organizationId();final row=await supabase.from('venues').insert({'organization_id':org,'name':name.text.trim(),'address':address.text.trim(),'city':city.text.trim(),'sport_types':[sport],'latitude':latitude,'longitude':longitude}).select().single();setState(() { venues.add(Map<String,dynamic>.from(row)); venueId=row['id'] as String; });}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Не удалось создать площадку: $e')));}}}
  Future<void> _pickDateTime(bool start) async {final now=DateTime.now();final d=await showDatePicker(context:context,initialDate:starts??now,firstDate:now,lastDate:now.add(const Duration(days:365)));if(d==null||!mounted)return;final t=await showTimePicker(context:context,initialTime:TimeOfDay.fromDateTime(starts??now));if(t==null)return;final value=DateTime(d.year,d.month,d.day,t.hour,t.minute);setState(()=>start?starts=value:ends=value);}
  Future<void> _create() async {if(title.text.trim().isEmpty||venueId==null||starts==null||max.text.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Заполните название, площадку, время и количество участников')));return;}setState(()=>busy=true);try{final org=await SportRoomData.organizationId();await supabase.from('games').insert({'organization_id':org,'venue_id':venueId,'title':title.text.trim(),'sport':sport,'starts_at':starts!.toUtc().toIso8601String(),'ends_at':(ends??starts!.add(const Duration(hours:1))).toUtc().toIso8601String(),'max_players':int.parse(max.text),'status':'published'});if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Игра опубликована!')));title.clear();setState(() { starts=null; ends=null; });}}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Ошибка: $e')));}finally{if(mounted)setState(()=>busy=false);}}
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.fromLTRB(20,18,20,90),children:[const Text('Создать игру',style:TextStyle(fontSize:29,fontWeight:FontWeight.w800)),const SizedBox(height:20),const Text('1. Вид спорта',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:8),Wrap(spacing:8,children:[ChoiceChip(label:const Text('⚽ Футбол'),selected:sport=='football',onSelected:(_)=>setState(()=>sport='football')),ChoiceChip(label:const Text('🏐 Волейбол'),selected:sport=='volleyball',onSelected:(_)=>setState(()=>sport='volleyball')),ChoiceChip(label:const Text('🏀 Баскетбол'),selected:sport=='basketball',onSelected:(_)=>setState(()=>sport='basketball'))]),const SizedBox(height:18),const Text('2. Спортивная площадка',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:8),Row(children:[Expanded(child:DropdownButtonFormField<String>(value:venueId,items:venues.map((v)=>DropdownMenuItem(value:v['id'] as String,child:Text(v['name'] as String))).toList(),onChanged:(v)=>setState(()=>venueId=v),decoration:InputDecoration(hintText:venues.isEmpty?'Нет площадок':'Выберите площадку',filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none)))),const SizedBox(width:8),IconButton.filled(onPressed:_addVenue,icon:const Icon(Icons.add))]),const SizedBox(height:18),const Text('3. Детали игры',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:8),AuthField(controller:title,label:'Название игры',icon:Icons.edit_outlined),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:()=>_pickDateTime(true),icon:const Icon(Icons.calendar_today),label:Text(starts==null?'Дата и время':SportRoomData.dateTime(starts!.toIso8601String())))),const SizedBox(width:8),SizedBox(width:100,child:TextField(controller:max,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Мест',filled:true,fillColor:Colors.white,border:OutlineInputBorder())))]),const SizedBox(height:20),FilledButton(onPressed:busy?null:_create,child:Padding(padding:const EdgeInsets.all(13),child:Text(busy?'Публикация…':'Опубликовать игру')))]);
}

class EmptyState extends StatelessWidget { final String text; const EmptyState({super.key,required this.text}); @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.all(28),child:Center(child:Text(text,textAlign:TextAlign.center,style:const TextStyle(color:Colors.black54)))); }

class SectionTitle extends StatelessWidget { final String title; final String? action; const SectionTitle({super.key,required this.title,this.action}); @override Widget build(BuildContext context)=>Row(children:[Expanded(child:Text(title,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))),if(action!=null)Text(action!,style:const TextStyle(color:Color(0xFF1769FF),fontWeight:FontWeight.bold))]); }
class SportChip extends StatelessWidget { final String emoji,text; const SportChip(this.emoji,this.text,{super.key}); @override Widget build(BuildContext context)=>Expanded(child:Container(padding:const EdgeInsets.symmetric(vertical:14),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16)),child:Column(children:[Text(emoji,style:const TextStyle(fontSize:27)),const SizedBox(height:5),Text(text,style:const TextStyle(fontWeight:FontWeight.w600))]))); }
class FilterBox extends StatelessWidget { final IconData icon; final String text; const FilterBox({super.key,required this.icon,required this.text}); @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(14)),child:Row(children:[Icon(icon,size:19),const SizedBox(width:7),Text(text)])); }
class SettingsTile extends StatelessWidget { final IconData icon; final String title,subtitle; const SettingsTile({super.key,required this.icon,required this.title,required this.subtitle}); @override Widget build(BuildContext context)=>Card(elevation:0,child:ListTile(leading:CircleAvatar(backgroundColor:const Color(0xFFEAF1FF),child:Icon(icon,color:const Color(0xFF1769FF))),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w600)),subtitle:Text(subtitle),trailing:const Icon(Icons.chevron_right))); }
class StatBox extends StatelessWidget { final String title,value; const StatBox(this.title,this.value,{super.key}); @override Widget build(BuildContext context)=>Expanded(child:Container(padding:const EdgeInsets.all(13),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16)),child:Column(children:[Text(value,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w800)),const SizedBox(height:3),Text(title,textAlign:TextAlign.center,style:const TextStyle(fontSize:11,color:Colors.black54))]))); }
class Field extends StatelessWidget { final String label,hint; const Field({super.key,required this.label,required this.hint}); @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:7),TextField(decoration:InputDecoration(hintText:hint,filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none)))])); }
class InfoLine extends StatelessWidget { final IconData icon; final String text; const InfoLine(this.icon,this.text,{super.key}); @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.symmetric(vertical:7),child:Row(children:[Icon(icon,size:20,color:const Color(0xFF1769FF)),const SizedBox(width:12),Expanded(child:Text(text,style:const TextStyle(fontSize:15)))])); }


class VenueLocationPicker extends StatefulWidget {
  final double initialLat;
  final double initialLng;
  final String address;
  const VenueLocationPicker({
    super.key,
    this.initialLat = -36.8509,
    this.initialLng = 174.7645,
    this.address = '',
  });

  @override
  State<VenueLocationPicker> createState() => _VenueLocationPickerState();
}

class _VenueLocationPickerState extends State<VenueLocationPicker> {
  late LatLng selected;
  final MapController mapController = MapController();
  bool locating = false;

  @override
  void initState() {
    super.initState();
    selected = LatLng(widget.initialLat, widget.initialLng);
  }

  Future<void> useMyLocation() async {
    setState(() => locating = true);
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) throw Exception('Геолокация отключена');

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        throw Exception('Нет разрешения на геолокацию');
      }

      final p = await Geolocator.getCurrentPosition();
      final point = LatLng(p.latitude, p.longitude);
      setState(() => selected = point);
      mapController.move(point, 16);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e')),
        );
      }
    } finally {
      if (mounted) setState(() => locating = false);
    }
  }

  Future<void> searchAddress() async {
    if (widget.address.trim().isEmpty) return;
    try {
      final results = await locationFromAddress(widget.address);
      if (results.isEmpty) return;
      final l = results.first;
      final point = LatLng(l.latitude, l.longitude);
      setState(() => selected = point);
      mapController.move(point, 16);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Адрес не удалось найти. Переместите маркер вручную.')),
        );
      }
    }
  }

  void confirm() {
    Navigator.pop(context, selected);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Местоположение площадки'),
        actions: [
          IconButton(
            tooltip: 'Моё местоположение',
            onPressed: locating ? null : useMyLocation,
            icon: locating
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.my_location),
          ),
        ],
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: mapController,
            options: MapOptions(
              initialCenter: selected,
              initialZoom: 15,
              onTap: (_, point) => setState(() => selected = point),
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.sportroom.app',
              ),
              MarkerLayer(
                markers: [
                  Marker(
                    point: selected,
                    width: 56,
                    height: 56,
                    child: GestureDetector(
                      onLongPressStart: (_) {},
                      child: const Icon(
                        Icons.location_on,
                        size: 52,
                        color: Color(0xFF1769FF),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          Positioned(
            left: 16,
            right: 16,
            top: 16,
            child: Card(
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    const Icon(Icons.touch_app, color: Color(0xFF1769FF)),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text(
                        'Нажмите на карте, чтобы переместить точку. '
                        'Для точной настройки можно выбрать место вручную.',
                      ),
                    ),
                    if (widget.address.isNotEmpty)
                      IconButton(
                        tooltip: 'Найти адрес',
                        onPressed: searchAddress,
                        icon: const Icon(Icons.search),
                      ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 18,
            child: FilledButton.icon(
              onPressed: confirm,
              icon: const Icon(Icons.check),
              label: const Padding(
                padding: EdgeInsets.all(12),
                child: Text('Подтвердить место'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
