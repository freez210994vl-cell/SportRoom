# SportRoom — final iOS upload checklist

## Apple
[ ] Apple Developer Program active
[ ] App Store Connect access
[ ] Latest agreements accepted
[ ] App record created
[ ] Bundle ID: com.sportroom.app

## Build
[ ] Full Flutter iOS project generated (`flutter create . --platforms=ios`)
[ ] Xcode 26+ installed
[ ] iOS 26 SDK or later
[ ] Signing team configured
[ ] Bundle ID matches com.sportroom.app
[ ] Version 1.0.0
[ ] Build 1
[ ] `flutter build ipa --release` succeeds
[ ] Build uploaded to App Store Connect

## Product
[ ] App icon added to Assets.xcassets
[ ] Real iPhone screenshots captured from the production build
[ ] App description entered
[ ] Keywords entered
[ ] Category selected
[ ] Age rating completed
[ ] App Privacy completed
[ ] Privacy Policy URL added
[ ] Support URL added

## TestFlight
[ ] Build processed
[ ] Internal test group created
[ ] Real iPhone tested
[ ] Registration tested
[ ] Organization tested
[ ] Venue creation tested
[ ] Map/location tested
[ ] Game creation tested
[ ] Join game tested
[ ] Duplicate join tested
[ ] Full game capacity tested
[ ] Sign out / sign in tested

## App Review
[ ] Review notes completed
[ ] Test account provided if needed
[ ] Submit for Beta App Review if external testing requires it
[ ] Submit final build to App Review only after TestFlight passes
