# SportRoom — Privacy Policy (Draft)

SportRoom uses account information and location data to provide its sports discovery and event features.

## Data we may collect
- Name and profile information
- Email address and phone number
- Account identifier
- Organization and venue information
- Approximate/precise device location when the user enables nearby search
- Game participation information

## Why we use it
We use this information to authenticate accounts, manage organizations and venues, show nearby games, manage participation, and provide app functionality.

## Third parties
SportRoom uses Supabase for authentication and database services. Map tiles may be provided by OpenStreetMap infrastructure depending on the production map configuration.

## User choices
Location access can be denied or disabled in iOS Settings. Account data should be handled according to the final account deletion workflow.

## Contact
Replace this section with the legal contact email and the public privacy-policy URL before App Store submission.

This is a draft for product setup and is not legal advice.
