# SportRoom — App Store metadata

## App name
SportRoom

## Subtitle
Игры рядом. Играй вместе.

## Promotional text
Находи спортивные игры рядом, создавай свои мероприятия и присоединяйся к другим игрокам.

## Description
SportRoom помогает находить людей для совместных спортивных игр.

Находи футбол, волейбол, баскетбол и другие спортивные мероприятия рядом с тобой. Открывай комнату игры, смотри время и место проведения и присоединяйся одним нажатием.

### Для пользователей
• Поиск игр рядом с вами
• Карта спортивных площадок
• Фильтры по видам спорта
• Информация о времени и месте
• Количество свободных мест
• Присоединение к игре
• Раздел ваших игр

### Для организаций
• Регистрация организации
• Создание спортивных площадок
• Указание точного места на карте
• Создание спортивных игр
• Управление количеством участников

SportRoom создан для того, чтобы сделать поиск компании для спорта простым и удобным.

## Keywords
спорт,футбол,волейбол,баскетбол,игры,спортсмены,команда,площадка,спорт рядом,матч

## Category
Primary: Sports
Secondary: Social Networking

## Age rating
Заполнить в App Store Connect по фактическим функциям приложения. Вопросы Apple по возрастному рейтингу были обновлены в 2026 году.

## Support URL
ЗАМЕНИТЬ на реальную страницу поддержки.

## Marketing URL
ЗАМЕНИТЬ на реальный сайт/лендинг, если он будет.

## Privacy Policy URL
ЗАМЕНИТЬ на публичную страницу политики конфиденциальности.

## App Review notes
SportRoom is a sports activity discovery and participation app.

Test flow:
1. Create a regular user account.
2. Confirm email if email confirmation is enabled.
3. Sign in.
4. View nearby games on the map/list.
5. Open a game and tap Join.
6. For organization testing, create an organization account, create a venue, then create a game.

The app uses Supabase for authentication and database services. Location permission is used to show nearby sports games and venues.

If a test account is required, provide a dedicated App Review account in App Store Connect before submission.
