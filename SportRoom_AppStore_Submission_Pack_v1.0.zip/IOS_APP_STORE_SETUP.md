# SportRoom iOS / App Store setup

## Identity
- App name: SportRoom
- Bundle ID: com.sportroom.app
- Version: 1.0.0
- Build: 1

## Capabilities / permissions
- Location When In Use is configured in Runner/Info.plist.
- Supabase Auth/database are configured by the Flutter app.

## Privacy / App Store Connect
Declare these data categories in App Store Connect based on the final implementation:
- Contact info: email, phone (account creation)
- Identifiers: user/account identifier
- Location: precise location, when the user enables nearby search
- User content/profile data: name/profile information
- Authentication information: account credentials are handled by Supabase Auth

Do not claim data categories that the final production build does not collect.
Provide a public Privacy Policy URL before submission.

## TestFlight
1. On a Mac, open the project with Flutter/Xcode.
2. Run `flutter pub get`.
3. Run `flutter build ipa --release`.
4. Open the generated archive in Xcode Organizer or upload using Transporter.
5. In App Store Connect, create the SportRoom app record with Bundle ID com.sportroom.app.
6. Upload build 1.
7. Add internal testers and test registration, organization creation, venue creation, game creation and joining.

## Before submission
- Verify Supabase production project and RLS.
- Verify email confirmation flow.
- Verify location permission prompt.
- Add final app icon assets in Assets.xcassets.
- Add App Store screenshots.
- Add Privacy Policy URL and App Privacy answers.
- Test on a physical iPhone.
