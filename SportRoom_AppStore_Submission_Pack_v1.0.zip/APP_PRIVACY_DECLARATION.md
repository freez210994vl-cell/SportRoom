# App Store Connect — App Privacy preparation

Use these as a checklist, but answer App Store Connect based on the exact production build.

## Data categories to review

### Contact Info
- Email address — account creation/authentication
- Phone number — profile/organization information, if collected in the final build

### Identifiers
- User ID / account identifier

### Location
- Precise Location — used when the user enables nearby games/venues

### User Content / Profile
- Name and profile information
- Organization information, if applicable

### Authentication
- Account credentials are handled by Supabase Auth. Do not claim that SportRoom itself stores raw passwords if it does not.

## Purpose
- App functionality
- Authentication/account management
- Nearby game discovery
- Game participation

## Important
Do not publish the draft as-is. Verify the final Flutter build, Supabase configuration, analytics/SDKs, and actual collected data before answering Apple's privacy questionnaire.

A public Privacy Policy URL is required before submission.
