# SportRoom — App Store metadata (English)

## App name
SportRoom

## Subtitle
Find games. Play together.

## Promotional text
Find sports games nearby, create your own events, and join other players.

## Description
SportRoom makes it easier to find people to play sports with.

Discover football, volleyball, basketball, and other sports activities nearby. Open a game room, see the time and venue, and join with one tap.

### For players
• Discover games nearby
• Map of sports venues
• Sport filters
• Game time and venue details
• Available player count
• One-tap joining
• Your games

### For organizations
• Organization accounts
• Create sports venues
• Set the exact venue location on the map
• Create sports games
• Manage player capacity

SportRoom is designed to make finding people to play sports with simple and convenient.

## Keywords
sports,football,volleyball,basketball,games,players,teams,venues,nearby sports,match

## Category
Primary: Sports
Secondary: Social Networking

## App Review notes
SportRoom is a sports activity discovery and participation app.

Test flow:
1. Create a regular user account.
2. Confirm email if email confirmation is enabled.
3. Sign in.
4. View nearby games on the map/list.
5. Open a game and tap Join.
6. For organization testing, create an organization account, create a venue, then create a game.

The app uses Supabase for authentication and database services. Location permission is used to show nearby sports games and venues.
